print("salom dunyo")
print("man 'sifat' uquv markazida ishlayman")
print('Navro\'z yaxshi o\'quvchi')
print("Navro'z yaxshi o'quvchi")
print("odami ersang demagil odami \nodami ersang demagil odami")
print("""odami ersang demagil odami 
      



      odami ersang demagil odami""")
print(9+5)
print(362-65)
print(2+5*3-1)
print(25/5)
print(25//5)
print(11//5)
print(11%5)
print(5**5)


